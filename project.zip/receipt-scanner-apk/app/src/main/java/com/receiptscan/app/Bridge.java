package com.receiptscan.app;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

/**
 * 웹앱(JavaScript) ↔ 안드로이드 연결.
 * PDF는 MediaStore를 통해 "내 파일 > Documents > 영수증 > <폴더>" 에 실제 파일로 저장됩니다.
 * 모든 메서드는 JSON 문자열을 돌려주며, 실패 시 {"error": "..."} 입니다.
 */
public class Bridge {
    public static final String ROOT = "영수증";
    private final Activity act;

    public Bridge(Activity act) { this.act = act; }

    private ContentResolver cr() { return act.getContentResolver(); }
    private static Uri collection() { return MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY); }
    private static String rel(String folder) {
        String base = Environment.DIRECTORY_DOCUMENTS + "/" + ROOT + "/";
        return (folder == null || folder.isEmpty()) ? base : base + folder + "/";
    }

    private static String err(Exception e) {
        try { return new JSONObject().put("error", String.valueOf(e.getMessage() != null ? e.getMessage() : e)).toString(); }
        catch (Exception x) { return "{\"error\":\"unknown\"}"; }
    }

    private static String clean(String s) {
        if (s == null) return "";
        return s.replaceAll("[\\\\/:*?\"<>|\\n\\r\\t]", "_").trim();
    }

    @JavascriptInterface
    public String info() {
        try {
            return new JSONObject()
                    .put("root", Environment.DIRECTORY_DOCUMENTS + "/" + ROOT)
                    .put("version", BuildInfo.VERSION)
                    .toString();
        } catch (Exception e) { return err(e); }
    }

    @JavascriptInterface
    public void toast(String msg) {
        act.runOnUiThread(() -> Toast.makeText(act, msg, Toast.LENGTH_SHORT).show());
    }

    /** base64 PDF 를 Documents/영수증/<folder>/<name>.pdf 로 저장 */
    @JavascriptInterface
    public String savePdf(String base64, String folder, String name) {
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            String f = clean(folder);
            String n = clean(name);
            if (n.isEmpty()) n = "영수증";
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, n + ".pdf");
            v.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, rel(f));
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = cr().insert(collection(), v);
            if (uri == null) throw new Exception("저장 위치를 만들 수 없습니다");
            try (OutputStream out = cr().openOutputStream(uri)) {
                if (out == null) throw new Exception("파일을 열 수 없습니다");
                out.write(data);
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr().update(uri, done, null, null);
            return describe(uri).put("size", data.length).toString();
        } catch (Exception e) { return err(e); }
    }

    private JSONObject describe(Uri uri) throws Exception {
        JSONObject o = new JSONObject().put("uri", uri.toString());
        String[] proj = {MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.RELATIVE_PATH, MediaStore.MediaColumns.SIZE};
        try (Cursor c = cr().query(uri, proj, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String dn = c.getString(0), rp = c.getString(1);
                o.put("displayName", dn).put("path", (rp == null ? "" : rp) + dn)
                 .put("name", dn != null && dn.endsWith(".pdf") ? dn.substring(0, dn.length() - 4) : dn);
            }
        }
        return o;
    }

    @JavascriptInterface
    public String describe(String uriStr) {
        try { return describe(Uri.parse(uriStr)).toString(); } catch (Exception e) { return err(e); }
    }

    @JavascriptInterface
    public String readPdf(String uriStr) {
        try (InputStream in = cr().openInputStream(Uri.parse(uriStr))) {
            if (in == null) throw new Exception("파일이 없습니다");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return new JSONObject().put("base64", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)).toString();
        } catch (Exception e) { return err(e); }
    }

    @JavascriptInterface
    public String deletePdf(String uriStr) {
        try {
            int n = cr().delete(Uri.parse(uriStr), null, null);
            return new JSONObject().put("deleted", n).toString();
        } catch (Exception e) { return err(e); }
    }

    @JavascriptInterface
    public String renamePdf(String uriStr, String newName) {
        try {
            Uri uri = Uri.parse(uriStr);
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, clean(newName) + ".pdf");
            cr().update(uri, v, null, null);
            return describe(uri).toString();
        } catch (Exception e) { return err(e); }
    }

    @JavascriptInterface
    public String movePdf(String uriStr, String folder) {
        try {
            Uri uri = Uri.parse(uriStr);
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, rel(clean(folder)));
            cr().update(uri, v, null, null);
            return describe(uri).toString();
        } catch (Exception e) { return err(e); }
    }

    /** 폴더 이름 변경: 그 폴더 안의 모든 PDF 경로를 바꿈 */
    @JavascriptInterface
    public String renameFolder(String oldName, String newName) {
        try {
            String[] proj = {MediaStore.MediaColumns._ID};
            ArrayList<Long> ids = new ArrayList<>();
            try (Cursor c = cr().query(collection(), proj, MediaStore.MediaColumns.RELATIVE_PATH + "=?", new String[]{rel(clean(oldName))}, null)) {
                while (c != null && c.moveToNext()) ids.add(c.getLong(0));
            }
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, rel(clean(newName)));
            int n = 0;
            for (long id : ids) n += cr().update(ContentUris.withAppendedId(collection(), id), v, null, null);
            return new JSONObject().put("moved", n).toString();
        } catch (Exception e) { return err(e); }
    }

    @JavascriptInterface
    public void openPdf(String uriStr) {
        act.runOnUiThread(() -> {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW)
                        .setDataAndType(Uri.parse(uriStr), "application/pdf")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                act.startActivity(Intent.createChooser(i, "PDF 열기"));
            } catch (Exception e) {
                Toast.makeText(act, "PDF를 열 수 있는 앱이 없습니다", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** 이미 저장된 PDF 내용을 새 내용으로 덮어씀 (문서에 쪽이 추가·삭제될 때) */
    @JavascriptInterface
    public String replacePdf(String uriStr, String base64) {
        try {
            Uri uri = Uri.parse(uriStr);
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            try (OutputStream out = cr().openOutputStream(uri, "wt")) {
                if (out == null) throw new Exception("파일을 열 수 없습니다");
                out.write(data);
            }
            return describe(uri).put("size", data.length).toString();
        } catch (Exception e) { return err(e); }
    }

    /** 정산표(CSV) 등 일반 파일을 Documents/영수증 에 저장 */
    @JavascriptInterface
    public String saveFile(String base64, String fileName, String mime) {
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, clean(fileName));
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, rel(""));
            Uri uri = cr().insert(collection(), v);
            if (uri == null) throw new Exception("저장 위치를 만들 수 없습니다");
            try (OutputStream out = cr().openOutputStream(uri)) {
                if (out == null) throw new Exception("파일을 열 수 없습니다");
                out.write(data);
            }
            return describe(uri).toString();
        } catch (Exception e) { return err(e); }
    }

    /** 영수증 사진을 갤러리(Pictures/영수증)에 저장 */
    @JavascriptInterface
    public String saveImage(String base64, String name) {
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, clean(name) + ".jpg");
            v.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + ROOT + "/");
            Uri uri = cr().insert(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), v);
            if (uri == null) throw new Exception("갤러리에 저장할 수 없습니다");
            try (OutputStream out = cr().openOutputStream(uri)) {
                if (out == null) throw new Exception("파일을 열 수 없습니다");
                out.write(data);
            }
            return new JSONObject().put("uri", uri.toString()).toString();
        } catch (Exception e) { return err(e); }
    }

    @JavascriptInterface
    public void copyText(String text) {
        act.runOnUiThread(() -> {
            android.content.ClipboardManager cm = (android.content.ClipboardManager) act.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("영수증", text));
        });
    }

    @JavascriptInterface
    public void shareUris(String urisJson, String mime) {
        act.runOnUiThread(() -> {
            try {
                JSONArray arr = new JSONArray(urisJson);
                ArrayList<Uri> uris = new ArrayList<>();
                for (int i = 0; i < arr.length(); i++) uris.add(Uri.parse(arr.getString(i)));
                if (uris.isEmpty()) return;
                Intent i;
                if (uris.size() == 1) i = new Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris.get(0));
                else i = new Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                i.setType(mime == null || mime.isEmpty() ? "*/*" : mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                act.startActivity(Intent.createChooser(i, "공유"));
            } catch (Exception e) {
                Toast.makeText(act, "공유 실패: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @JavascriptInterface
    public void sharePdf(String urisJson) {
        act.runOnUiThread(() -> {
            try {
                JSONArray arr = new JSONArray(urisJson);
                ArrayList<Uri> uris = new ArrayList<>();
                for (int i = 0; i < arr.length(); i++) uris.add(Uri.parse(arr.getString(i)));
                if (uris.isEmpty()) return;
                Intent i;
                if (uris.size() == 1) i = new Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris.get(0));
                else i = new Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                i.setType("application/pdf").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                act.startActivity(Intent.createChooser(i, "영수증 공유"));
            } catch (Exception e) {
                Toast.makeText(act, "공유 실패: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
