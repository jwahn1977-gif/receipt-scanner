package com.receiptscan.app;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.Intent;
import android.content.IntentSender;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.api.Scope;

import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 1001;
    private static final int REQ_PICK = 1002;
    private static final int REQ_AUTH = 1003;
    /** 앱이 만든 파일만 다루는 드라이브 권한 */
    private static final String DRIVE_SCOPE = "https://www.googleapis.com/auth/drive.file";

    private WebView web;
    private Bridge bridge;
    private LocalServer server;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private String authCb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setStatusBarColor(Color.parseColor("#0F1213"));
        w.setNavigationBarColor(Color.parseColor("#0F1213"));

        // 지난번 드라이브에서 받은 임시 파일 정리
        File[] old = Bridge.dlDir(this).listFiles();
        if (old != null) for (File f : old) f.delete();

        server = new LocalServer(getAssets(), Bridge.dlDir(this));
        int port;
        try {
            port = server.start();
        } catch (IOException e) {
            Toast.makeText(this, "앱을 시작할 수 없습니다: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0F1213"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        bridge = new Bridge(this);
        bridge.attach(web);
        web.addJavascriptInterface(bridge, "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest req) {
                Uri u = req.getUrl();
                if ("127.0.0.1".equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try {
                    if (params.isCaptureEnabled()) launchCamera();
                    else launchPicker(params.getAcceptTypes(), params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                } catch (Exception e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "카메라/앨범을 열 수 없습니다", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });
        setContentView(web);
        web.clearCache(true);
        web.loadUrl("http://127.0.0.1:" + port + "/index.html?v=" + BuildInfo.VERSION + "&t=" + System.currentTimeMillis());
    }

    /** 화면 모드(라이트/다크)에 맞춰 상태 표시줄 색과 아이콘 색을 바꿈 */
    void applyBars(boolean dark) {
        Window w = getWindow();
        int c = Color.parseColor(dark ? "#0F1213" : "#F2F4F3");
        w.setStatusBarColor(c);
        w.setNavigationBarColor(c);
        if (web != null) web.setBackgroundColor(c);
        View d = w.getDecorView();
        int f = d.getSystemUiVisibility();
        if (dark) f &= ~(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        else f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        d.setSystemUiVisibility(f);
    }

    /* ───────── 구글 드라이브 로그인 ───────── */
    void authorizeDrive(String cbId, boolean interactive) {
        AuthorizationRequest req = AuthorizationRequest.builder()
                .setRequestedScopes(Collections.singletonList(new Scope(DRIVE_SCOPE)))
                .build();
        try {
            Identity.getAuthorizationClient(this).authorize(req)
                    .addOnSuccessListener(res -> {
                        if (res.hasResolution()) {
                            if (!interactive) { bridge.reply(cbId, Bridge.errJson("로그인이 필요합니다", "need_login", 0)); return; }
                            PendingIntent pi = res.getPendingIntent();
                            if (pi == null) { bridge.reply(cbId, Bridge.errJson("로그인 창을 열 수 없습니다", null, 0)); return; }
                            try {
                                if (authCb != null) bridge.reply(authCb, Bridge.errJson("취소했습니다", "canceled", 0));
                                authCb = cbId;
                                startIntentSenderForResult(pi.getIntentSender(), REQ_AUTH, null, 0, 0, 0);
                            } catch (IntentSender.SendIntentException e) {
                                authCb = null;
                                bridge.reply(cbId, Bridge.errJson("로그인 창을 열 수 없습니다: " + e.getMessage(), null, 0));
                            }
                        } else {
                            bridge.reply(cbId, tokenJson(res));
                        }
                    })
                    .addOnFailureListener(e -> bridge.reply(cbId, authFailure(e)));
        } catch (Exception e) {
            bridge.reply(cbId, authFailure(e));
        }
    }

    private static String tokenJson(AuthorizationResult res) {
        try {
            String t = res.getAccessToken();
            if (t == null || t.isEmpty()) return Bridge.errJson("권한을 받지 못했습니다", null, 0);
            return new JSONObject().put("token", t).toString();
        } catch (Exception e) { return Bridge.errJson(e.getMessage(), null, 0); }
    }

    private static String authFailure(Exception e) {
        if (e instanceof ApiException) {
            int code = ((ApiException) e).getStatusCode();
            if (code == CommonStatusCodes.DEVELOPER_ERROR)
                return Bridge.errJson("구글 클라우드에 앱이 등록되지 않았습니다 (코드 10)", "need_setup", code);
            if (code == CommonStatusCodes.NETWORK_ERROR)
                return Bridge.errJson("인터넷에 연결할 수 없습니다", "network", code);
            if (code == CommonStatusCodes.CANCELED)
                return Bridge.errJson("취소했습니다", "canceled", code);
            return Bridge.errJson("구글 로그인 오류 (코드 " + code + ")", null, code);
        }
        return Bridge.errJson(String.valueOf(e.getMessage() != null ? e.getMessage() : e), null, 0);
    }

    /* ───────── 카메라 · 파일 선택 ───────── */
    private void launchCamera() {
        File dir = CaptureProvider.dir(this);
        for (File old : dir.listFiles() != null ? dir.listFiles() : new File[0]) old.delete();
        File f = new File(dir, "capture_" + System.currentTimeMillis() + ".jpg");
        cameraUri = CaptureProvider.uriFor(f);
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                .putExtra(MediaStore.EXTRA_OUTPUT, cameraUri)
                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(i, REQ_CAMERA);
    }

    private void launchPicker(String[] accept, boolean multiple) {
        ArrayList<String> types = new ArrayList<>();
        if (accept != null) for (String a : accept) {
            if (a == null) continue;
            for (String t : a.split(",")) {
                t = t.trim();
                if (t.isEmpty()) continue;
                if (t.equals(".pdf")) t = "application/pdf";
                if (t.equals(".zip")) t = "application/zip";
                types.add(t);
            }
        }
        if (types.isEmpty()) types.add("image/*");
        Intent i = new Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE);
        if (types.size() == 1 && !types.get(0).equals("application/zip")) i.setType(types.get(0));
        else {
            if (types.contains("application/zip")) types.addAll(Arrays.asList("application/x-zip-compressed", "application/octet-stream"));
            i.setType("*/*").putExtra(Intent.EXTRA_MIME_TYPES, types.toArray(new String[0]));
        }
        if (multiple) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        String title = types.contains("application/zip") ? "백업 파일 선택" : types.contains("application/pdf") ? "PDF·사진 선택" : "영수증 사진 선택";
        startActivityForResult(Intent.createChooser(i, title), REQ_PICK);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_AUTH) {
            String cb = authCb; authCb = null;
            if (cb == null) return;
            if (res != RESULT_OK) { bridge.reply(cb, Bridge.errJson("취소했습니다", "canceled", 0)); return; }
            try {
                AuthorizationResult r = Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data);
                bridge.reply(cb, tokenJson(r));
            } catch (ApiException e) {
                bridge.reply(cb, authFailure(e));
            }
            return;
        }
        if (fileCallback == null) return;
        Uri[] result = null;
        if (res == RESULT_OK) {
            if (req == REQ_CAMERA && cameraUri != null) result = new Uri[]{cameraUri};
            else if (req == REQ_PICK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null && clip.getItemCount() > 0) {
                    result = new Uri[clip.getItemCount()];
                    for (int k = 0; k < clip.getItemCount(); k++) result[k] = clip.getItemAt(k).getUri();
                } else if (data.getData() != null) result = new Uri[]{data.getData()};
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    @Override
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        // 웹앱에 먼저 물어봄: 열린 화면(스캔/상세/팝업)이 있으면 그것을 닫고 true 반환
        web.evaluateJavascript("(function(){try{return window.appBack?window.appBack():false}catch(e){return false}})()", v -> {
            if (!"true".equals(v)) finishOrSuper();
        });
    }

    private void finishOrSuper() {
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (server != null) server.stop();
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
