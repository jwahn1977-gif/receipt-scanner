package com.receiptscan.app;
public final class BuildInfo { public static final String VERSION = "2.0"; private BuildInfo() {} }
