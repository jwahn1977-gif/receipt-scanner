package com.receiptscan.app;
public final class BuildInfo { public static final String VERSION = "1.0"; private BuildInfo() {} }
