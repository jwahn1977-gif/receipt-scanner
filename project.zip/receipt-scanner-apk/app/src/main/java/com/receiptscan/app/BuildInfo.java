package com.receiptscan.app;
public final class BuildInfo { public static final String VERSION = "2.6"; private BuildInfo() {} }
