package com.receiptscan.app;

import android.content.res.AssetManager;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 앱 안에서만 접근 가능한 아주 작은 HTTP 서버.
 * assets 폴더의 웹앱을 http://127.0.0.1:포트/ 로 제공해서
 * WebView가 정상적인 출처(origin)를 갖게 하고(IndexedDB 영구 저장, Web Worker 동작),
 * Tesseract OCR 엔진(wasm)을 로컬에서 불러올 수 있게 합니다.
 */
public class LocalServer {
    private static final String TAG = "LocalServer";
    public static final int[] PORTS = {38471, 38472, 38473, 38474};

    private final AssetManager assets;
    private final File dlDir;
    private ServerSocket server;
    private ExecutorService pool;
    private int port = -1;

    public LocalServer(AssetManager assets, File dlDir) {
        this.assets = assets;
        this.dlDir = dlDir;
    }

    public int start() throws IOException {
        IOException last = null;
        for (int p : PORTS) {
            try {
                server = new ServerSocket(p, 16, InetAddress.getByName("127.0.0.1"));
                port = p;
                break;
            } catch (IOException e) {
                last = e;
            }
        }
        if (server == null) throw last != null ? last : new IOException("포트를 열 수 없습니다");
        pool = Executors.newFixedThreadPool(4);
        Thread t = new Thread(() -> {
            while (!server.isClosed()) {
                try {
                    Socket s = server.accept();
                    pool.execute(() -> handle(s));
                } catch (IOException e) {
                    if (!server.isClosed()) Log.w(TAG, "accept 실패", e);
                }
            }
        }, "local-http");
        t.setDaemon(true);
        t.start();
        return port;
    }

    public int getPort() {
        return port;
    }

    public void stop() {
        try { if (server != null) server.close(); } catch (IOException ignored) {}
        if (pool != null) pool.shutdownNow();
    }

    private void handle(Socket s) {
        try (Socket sock = s) {
            sock.setSoTimeout(15000);
            BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream(), "ISO-8859-1"));
            String line = in.readLine();
            if (line == null) return;
            String[] parts = line.split(" ");
            if (parts.length < 2) return;
            String method = parts[0];
            String path = parts[1];
            // 나머지 헤더는 읽고 버림
            String h;
            while ((h = in.readLine()) != null && !h.isEmpty()) { /* skip */ }

            int q = path.indexOf('?');
            if (q >= 0) path = path.substring(0, q);
            path = URLDecoder.decode(path, "UTF-8");
            if (path.equals("/") || path.isEmpty()) path = "/index.html";
            if (path.contains("..")) { send(sock.getOutputStream(), 403, "text/plain", "forbidden".getBytes(), null); return; }
            String asset = path.substring(1);

            OutputStream out = sock.getOutputStream();
            // 드라이브에서 받아 둔 임시 파일 (/_dl/이름)
            if (asset.startsWith("_dl/") && dlDir != null) {
                File f = new File(dlDir, asset.substring(4));
                if (!f.getName().equals(asset.substring(4)) || !f.isFile()) { send(out, 404, "text/plain", "not found".getBytes(), null); return; }
                String head = "HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\nCache-Control: no-store\r\nConnection: close\r\nContent-Length: " + f.length() + "\r\n\r\n";
                out.write(head.getBytes("ISO-8859-1"));
                try (InputStream fi = new FileInputStream(f)) {
                    byte[] buf = new byte[64 * 1024]; int n;
                    while ((n = fi.read(buf)) > 0) out.write(buf, 0, n);
                }
                out.flush();
                f.delete();
                return;
            }
            try (InputStream is = assets.open(asset)) {
                long len = -1;
                try { len = assets.openFd(asset).getLength(); } catch (IOException ignored) { /* 압축된 asset */ }
                String mime = mime(asset);
                StringBuilder head = new StringBuilder();
                head.append("HTTP/1.1 200 OK\r\n");
                head.append("Content-Type: ").append(mime).append("\r\n");
                head.append("Cache-Control: no-store, no-cache, must-revalidate, max-age=0\r\n");
                head.append("Pragma: no-cache\r\n");
                head.append("Connection: close\r\n");
                if (len >= 0) head.append("Content-Length: ").append(len).append("\r\n");
                head.append("\r\n");
                out.write(head.toString().getBytes("ISO-8859-1"));
                if (!method.equals("HEAD")) {
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = is.read(buf)) > 0) out.write(buf, 0, n);
                }
                out.flush();
            } catch (IOException notFound) {
                send(out, 404, "text/plain; charset=utf-8", ("not found: " + asset).getBytes("UTF-8"), null);
            }
        } catch (IOException e) {
            Log.d(TAG, "요청 처리 중 끊김: " + e.getMessage());
        }
    }

    private static void send(OutputStream out, int code, String mime, byte[] body, String extra) throws IOException {
        String head = "HTTP/1.1 " + code + " " + (code == 200 ? "OK" : code == 404 ? "Not Found" : "Error") + "\r\n"
                + "Content-Type: " + mime + "\r\nContent-Length: " + body.length + "\r\nConnection: close\r\n"
                + (extra != null ? extra : "") + "\r\n";
        out.write(head.getBytes("ISO-8859-1"));
        out.write(body);
        out.flush();
    }

    private static String mime(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".html")) return "text/html; charset=utf-8";
        if (n.endsWith(".js")) return "text/javascript; charset=utf-8";
        if (n.endsWith(".css")) return "text/css; charset=utf-8";
        if (n.endsWith(".json")) return "application/json";
        if (n.endsWith(".wasm")) return "application/wasm";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".svg")) return "image/svg+xml";
        if (n.endsWith(".woff2")) return "font/woff2";
        if (n.endsWith(".ttf")) return "font/ttf";
        if (n.endsWith(".traineddata")) return "application/octet-stream";
        return "application/octet-stream";
    }
}
