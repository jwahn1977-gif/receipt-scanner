plugins { id("com.android.application") }

android {
    namespace = "com.receiptscan.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.receiptscan.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 5
        versionName = "2.2"
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("receipt.keystore")
            storePassword = "receipt123"
            keyAlias = "receipt"
            keyPassword = "receipt123"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            // 배포용: 저장소의 debug 키로 서명 (개인 사용 목적). 스토어 배포 시에는 별도 키 필요.
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    androidResources { noCompress += listOf("traineddata", "wasm") }
}

dependencies {
    // 구글 계정 로그인(드라이브 권한 받기)
    implementation("com.google.android.gms:play-services-auth:21.2.0")
}
