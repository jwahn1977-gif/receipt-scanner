plugins { id("com.android.application") }

android {
    namespace = "com.receiptscan.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.receiptscan.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            // 배포용: 저장소의 debug 키로 서명 (개인 사용 목적). 스토어 배포 시에는 별도 키 필요.
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    androidResources { noCompress += listOf("traineddata", "wasm") }
}

dependencies { }
