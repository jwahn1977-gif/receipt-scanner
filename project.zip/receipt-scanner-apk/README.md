# 영수증 스캐너 (Android)

카메라로 영수증을 찍으면 테두리를 자동으로 잡아 반듯하게 펴고, 글자를 읽어
`날짜_상호_금액.pdf` 로 **내 파일 › Documents › 영수증 › 폴더** 에 저장하는 앱입니다.
인터넷 없이 모두 기기 안에서 처리됩니다.

## APK 받는 방법
이 저장소에 코드를 올리면 GitHub Actions가 자동으로 APK를 만듭니다 (약 5분).
1. 저장소 상단 **Releases** (오른쪽 메뉴) 를 엽니다.
2. 최신 항목의 **영수증스캐너.apk** 를 눌러 휴대폰에 내려받습니다.
3. 내려받은 파일을 열고 "출처를 알 수 없는 앱 설치" 를 허용한 뒤 설치합니다.

수동으로 다시 만들려면: **Actions → Build APK → Run workflow**.

## 기능
- 촬영/앨범 불러오기 → 영수증 영역 자동 감지, 네 모서리 수동 조정, 원근 보정
- 보정 필터: 문서(흑백·그림자 제거) / 선명 / 원본
- 한국어 OCR(Tesseract)로 날짜·상호·합계 금액 자동 입력, 폴더 자동 추천
- 여러 장을 PDF 한 개로 묶기
- 폴더별 보관, 이번 달·폴더 합계, 미리보기, 열기, 공유, 정보 수정, 폴더 이동, 삭제
- PDF는 MediaStore를 통해 `Documents/영수증/<폴더>/` 에 실제 파일로 저장

## 구조
- `app/src/main/assets/index.html` — 앱 화면과 처리 로직 전체 (WebView)
- `app/src/main/assets/tess/` — Tesseract OCR 엔진과 한국어/영어 학습 데이터
- `MainActivity.java` — WebView, 카메라/앨범 선택기, 뒤로 가기
- `LocalServer.java` — 앱 내부 전용 로컬 HTTP 서버 (OCR 엔진 로딩용)
- `Bridge.java` — PDF 저장/열기/공유/이동/삭제 (MediaStore)
- `CaptureProvider.java` — 카메라 촬영 임시 파일 제공
