# 영수증 스캐너 (Android)

카메라로 영수증을 찍으면 테두리를 자동으로 잡아 반듯하게 펴고, 글자를 읽어
`날짜_상호_금액.pdf` 로 **내 파일 › Documents › 영수증 › 폴더** 에 저장하는 앱입니다.
인터넷 없이 모두 기기 안에서 처리됩니다.

## APK 받는 방법
이 저장소에 코드를 올리면 GitHub Actions가 자동으로 APK를 만듭니다 (약 5분).
1. 저장소 상단 **Releases** (오른쪽 메뉴) 를 엽니다.
2. 최신 항목의 **영수증스캐너.apk** 를 눌러 휴대폰에 내려받습니다.
3. 내려받은 파일을 열고 "출처를 알 수 없는 앱 설치" 를 허용한 뒤 설치합니다.

수동으로 다시 만들려면: **Actions → Build APK → Run workflow**.

## 기능
- 촬영/앨범 불러오기 → 영수증 영역 자동 감지, 네 모서리 수동 조정, 원근 보정
- 보정 필터: 문서(흑백·그림자 제거) / 선명 / 원본
- 한국어 OCR(Tesseract)로 날짜·상호·합계 금액 자동 입력, 폴더 자동 추천
- 여러 장을 PDF 한 개로 묶기
- 폴더별 보관, 이번 달·폴더 합계, 미리보기, 열기, 공유, 정보 수정, 폴더 이동, 삭제
- PDF는 MediaStore를 통해 `Documents/영수증/<폴더>/` 에 실제 파일로 저장

## v2.2 새 기능
- 하단 탭: 홈 · 문서 · 촬영 · 도구 · 내 항목
- 문서 목록: 검색(이름·상호·금액·날짜), 정렬, 목록/격자 보기, 여러 개 선택(병합·공유·정산표·드라이브·삭제)
- 도구: 텍스트 추출, Excel(정산표), 이미지로·긴 이미지로, 서명, 워터마크, 타임스탬프, 파일 병합, 페이지 추출, 순서 변경, 압축
- 가져오기: 사진 여러 장 한 번에, PDF 파일
- 외화 영수증: 통화 자동 인식, 원화 환산액 입력, 합계는 원화 기준
- 상단 보기 설정: 글자 크기, 한국어/English, 시스템·라이트·다크, 강조 색상 6가지
- 동기화: Google Drive 로그인 동기화(아래 설정 필요), 백업 ZIP 내보내기·복원(OneDrive 등 공유)

## Google Drive 동기화 설정 (처음 한 번)
1. console.cloud.google.com 에서 프로젝트 만들기
2. API 및 서비스 › 라이브러리 › Google Drive API › 사용
3. OAuth 동의 화면: 외부, 테스트 사용자에 내 계정 추가
4. 사용자 인증 정보 › OAuth 클라이언트 ID › Android
   - 패키지 이름: `com.receiptscan.app`
   - SHA-1: `08:DF:4A:F4:89:1E:F4:77:6D:36:07:87:22:69:60:12:1B:20:A6:23` (저장소의 receipt.keystore)
5. 앱 › 내 항목 › Google 계정으로 로그인

앱은 `drive.file` 권한만 받아, 앱이 만든 파일(드라이브의 '영수증 스캐너' 폴더)만 읽고 씁니다.

## 구조
- `app/src/main/assets/index.html` — 앱 화면과 처리 로직 전체 (WebView)
- `app/src/main/assets/tess/` — Tesseract OCR 엔진과 한국어/영어 학습 데이터 (빌드 때 내려받음)
- `app/src/main/assets/pdfjs/` — PDF 가져오기용 pdf.js 3.11.174
- `MainActivity.java` — WebView, 카메라/앨범 선택기, 뒤로 가기
- `LocalServer.java` — 앱 내부 전용 로컬 HTTP 서버 (OCR 엔진 로딩용)
- `Bridge.java` — PDF 저장/열기/공유/이동/삭제 (MediaStore), 구글 API 요청
- `CaptureProvider.java` — 카메라 촬영 임시 파일 제공
